# OSINT Deep Briefing Engine
### Content Writer Edition — Multi-Provider AI

Investigative intelligence briefings powered by AI. Enter any entity name — the engine searches the internet, analyses it, and outputs a structured briefing with source citations.

---

## Features

- **No manual URLs needed** — AI searches the internet automatically
- **4 AI providers** — Groq & Gemini are FREE, no credit card required
- **Deep briefings** — Context, Network, Money Trail, Contradictions
- **Multiple output modes** — Briefing, Article, Thread, Newsletter
- **Legal review pass** — flags defamation risks before publishing
- **Watchlist** — monitor entities over time, get delta reports
- **Export** — Markdown, Word (.docx), JSON
- **Source citations** — every bullet references its source

---

## Providers

| Provider | Model | Free? | Key |
|---|---|---|---|
| `groq` | Llama 3.3 70B | ✅ FREE | [console.groq.com](https://console.groq.com) |
| `gemini` | Gemini 2.0 Flash | ✅ FREE | [aistudio.google.com](https://aistudio.google.com/app/apikey) |
| `claude` | Claude Sonnet 4 | Paid | [console.anthropic.com](https://console.anthropic.com) |
| `openai` | GPT-4o | Paid | [platform.openai.com](https://platform.openai.com/api-keys) |

> Claude provider has live web search built-in (best quality). Others use training knowledge.

---

## Setup

```bash
# 1. Clone the repo
git clone https://github.com/yourusername/osint-engine.git
cd osint-engine

# 2. Install dependencies
pip install -r requirements.txt

# 3. Set up your API keys
cp .env.example .env
# Edit .env and add your keys — this file is gitignored, never pushed
```

**.env file:**
```
GROQ_API_KEY=gsk_...
GEMINI_API_KEY=AIza...
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
```

---

## Usage

```bash
# Basic — AI searches internet automatically (uses Groq by default, FREE)
python osint_bot.py --target "Byju's"

# Use a different provider
python osint_bot.py --target "Adani Group" --provider gemini

# Focus on funding with deep dive
python osint_bot.py --target "XYZ NGO" --angle funding --depth deep

# Generate a full article
python osint_bot.py --target "ABC Media" --mode article --tone formal

# Thread + newsletter
python osint_bot.py --target "Entity" --mode thread
python osint_bot.py --target "Entity" --mode newsletter

# With quotes bank and SEO headlines
python osint_bot.py --target "Entity" --quotes --seo

# Legal review pass
python osint_bot.py --target "Entity" --mode article --legal-review

# Provide specific URLs to scrape (optional)
python osint_bot.py --target "Entity" --urls https://example.com https://other.com

# Export as Word document
python osint_bot.py --target "Entity" --export docx

# Export everything
python osint_bot.py --target "Entity" --export all

# Watchlist — monitor over time
python osint_bot.py --target "Entity" --watchlist add --urls https://example.com
python osint_bot.py --target "Entity" --watchlist run --provider groq
python osint_bot.py --watchlist list

# List all providers
python osint_bot.py --providers
```

---

## All Flags

| Flag | Options | Default | Description |
|---|---|---|---|
| `--target` | string | required | Entity to investigate |
| `--provider` | groq, gemini, claude, openai | groq | AI provider |
| `--mode` | briefing, article, thread, newsletter | briefing | Output format |
| `--depth` | standard, deep, financial, network | standard | Investigation depth |
| `--angle` | all, funding, network, contradictions, legal, timeline | all | Focus area |
| `--tone` | formal, tabloid, academic | formal | Article tone |
| `--urls` | URL list | — | Optional URLs to scrape |
| `--file` | filepath | — | Text file with URLs |
| `--quotes` | flag | off | Extract quotes bank |
| `--seo` | flag | off | Generate SEO headlines |
| `--legal-review` | flag | off | Legal compliance pass |
| `--export` | markdown, docx, json, all | markdown | Export format |
| `--redact-sources` | flag | off | Hash URLs in JSON export |
| `--watchlist` | add, run, list | — | Watchlist management |
| `--output-dir` | path | ./output | Output directory |

---

## Security

API keys are loaded from `.env` using `python-dotenv`. The `.env` file is in `.gitignore` and will never be pushed to GitHub.

**Never put API keys directly in the code.**

---

## Output Files

All files are saved to `./output/` (gitignored):

- `EntityName_briefing_TIMESTAMP.md` — full markdown briefing
- `EntityName_briefing_TIMESTAMP.docx` — Word document
- `EntityName_data_TIMESTAMP.json` — raw JSON data
- `EntityName_article_TIMESTAMP.txt` — article draft
- `EntityName_thread_TIMESTAMP.txt` — Twitter/X thread
- `EntityName_newsletter_TIMESTAMP.txt` — newsletter edition
- `EntityName_legal_review_TIMESTAMP.txt` — legal-reviewed content

---

## License

For research and journalism use. Verify all facts independently before publishing.
